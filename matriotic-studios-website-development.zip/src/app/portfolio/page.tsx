import type { Metadata } from "next";

import PageHero from "@/components/PageHero";
import CaseStudy from "@/components/portfolio/CaseStudy";
import { Reveal, SplitHeading } from "@/components/motion/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import Marquee from "@/components/Marquee";
import { WORK } from "@/lib/content";

export const metadata: Metadata = {
  title: "Portfolio",
  description:
    "Selected case studies from Matriotic Studios LLC — luxury e-commerce, fintech platforms, hospitality products and brand identities.",
};

const SECTORS = [
  "Luxury Retail",
  "Private Capital",
  "Hospitality",
  "Type & Design",
  "Architecture",
  "Private Clubs",
];

export default function PortfolioPage() {
  return (
    <>
      <PageHero
        breadcrumb="Portfolio"
        eyebrow="Selected work · 2024—2026"
        title="Work that earns its keep."
        accentFrom={2}
        lede="We measure every engagement against commercial outcomes, not awards. These are four of the projects we are most proud of — and the numbers that followed."
      />

      <Marquee items={SECTORS} speed={44} reverse />

      <div>
        {WORK.map((item, i) => (
          <CaseStudy
            key={item.slug}
            index={i}
            slug={item.slug}
            client={item.client}
            title={item.title}
            category={item.category}
            year={item.year}
            image={item.image}
            summary={item.summary}
            results={item.results}
            stack={item.stack}
          />
        ))}
      </div>

      <section className="py-28 text-center md:py-40">
        <div className="u-container">
          <Reveal>
            <p className="u-eyebrow">Next</p>
          </Reveal>
          <SplitHeading
            text="There is room for one more this quarter."
            accentFrom={4}
            className="u-display mx-auto mt-6 max-w-3xl text-[clamp(2.2rem,5.4vw,4rem)] text-white"
          />
          <Reveal delay={0.25}>
            <p className="mx-auto mt-7 max-w-xl leading-relaxed text-mist">
              If your project deserves the same level of attention, we would like to hear
              about it.
            </p>
          </Reveal>
          <Reveal delay={0.35}>
            <div className="mt-10 flex flex-wrap justify-center gap-4">
              <ButtonLink href="/contact">Enquire about availability</ButtonLink>
              <ButtonLink href="/services" variant="outline">
                Our services
              </ButtonLink>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}

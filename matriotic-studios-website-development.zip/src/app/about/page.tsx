import type { Metadata } from "next";
import Image from "next/image";

import PageHero from "@/components/PageHero";
import { Reveal, Stagger, StaggerItem, SplitHeading } from "@/components/motion/Reveal";
import { Parallax, WirePrism } from "@/components/decor/GoldAssets";
import { ButtonLink } from "@/components/ui/Button";
import { TEAM, PROCESS } from "@/lib/content";

export const metadata: Metadata = {
  title: "About Us",
  description:
    "The story of Matriotic Studios LLC — a deliberately small studio obsessed with craft, performance and the details nobody asks for.",
};

const VALUES = [
  {
    title: "Craft over volume",
    body: "We cap our client list. Fewer projects, more attention, work we are willing to put our name on.",
  },
  {
    title: "Performance is design",
    body: "A beautiful site that loads in four seconds is not a beautiful site. Speed is a feature we never trade away.",
  },
  {
    title: "Radical clarity",
    body: "Clear scopes, clear pricing, clear timelines. You will never wonder what we are doing or what it costs.",
  },
  {
    title: "Built to outlast",
    body: "Semantic, documented, standards-based code. If you ever leave us, you leave with something maintainable.",
  },
];

export default function AboutPage() {
  return (
    <>
      <PageHero
        breadcrumb="About"
        eyebrow="Est. 2020 · Wilmington, Delaware"
        title="A small studio with a long memory for detail."
        accentFrom={6}
        lede="Matriotic Studios LLC began as a reaction to an industry that had learned to ship quickly and forgotten how to ship well. We are the alternative to the template."
      />

      {/* Story */}
      <section className="relative py-24 md:py-36">
        <div className="u-container grid gap-16 lg:grid-cols-12 lg:gap-12">
          <div className="lg:col-span-5">
            <Parallax distance={40}>
              <div className="relative aspect-[4/5] overflow-hidden rounded-sm">
                <Image
                  src="/images/studio.jpg"
                  alt="The Matriotic Studios workspace at night"
                  fill
                  loading="lazy"
                  sizes="(max-width: 1024px) 100vw, 40vw"
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-obsidian/60 to-transparent" />
              </div>
            </Parallax>
          </div>

          <div className="lg:col-span-6 lg:col-start-7">
            <Reveal>
              <p className="u-eyebrow">Our story</p>
            </Reveal>
            <SplitHeading
              text="We started because the good work kept getting value-engineered away."
              accentFrom={8}
              className="u-display mt-6 text-[clamp(1.9rem,3.6vw,2.9rem)] text-white"
            />
            <Stagger className="mt-9 space-y-6 text-mist" delay={0.1}>
              <StaggerItem>
                <p className="leading-relaxed">
                  Marcus Ellery spent a decade inside agencies watching ambitious projects
                  get flattened — a brilliant concept reduced to a theme, a six-week build
                  compressed into three, a performance budget abandoned the week before
                  launch. The pattern was always the same: scale rewarded speed, and craft
                  paid the bill.
                </p>
              </StaggerItem>
              <StaggerItem>
                <p className="leading-relaxed">
                  Matriotic was founded on a stubborn premise: that a studio of four senior
                  people, working on three or four engagements at a time, can produce work
                  that forty people cannot. Six years and eighty-four launches later, the
                  premise has held.
                </p>
              </StaggerItem>
              <StaggerItem>
                <p className="leading-relaxed">
                  We write our own code. We draw our own type scales. We argue about easing
                  curves. And we measure everything, because taste without evidence is just
                  opinion.
                </p>
              </StaggerItem>
            </Stagger>

            <Reveal delay={0.25}>
              <div className="mt-12 border-l-2 border-gold/60 pl-7">
                <p className="u-display text-2xl italic leading-snug text-white">
                  &ldquo;If it does not survive a hard look on a slow phone, it is not
                  finished.&rdquo;
                </p>
                <p className="mt-4 text-xs uppercase tracking-[0.2em] text-mist">
                  Marcus Ellery — Founder
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Mission + values */}
      <section className="relative overflow-hidden border-y border-white/[0.07] bg-ink/40 py-24 md:py-36">
        <WirePrism className="pointer-events-none absolute -right-20 top-10 hidden h-[28rem] w-[24rem] opacity-40 lg:block" />
        <div className="u-container relative">
          <div className="max-w-3xl">
            <Reveal>
              <p className="u-eyebrow">Mission</p>
            </Reveal>
            <SplitHeading
              text="To make the open web feel expensive again."
              accentFrom={5}
              className="u-display mt-6 text-[clamp(2rem,4.6vw,3.5rem)] text-white"
            />
            <Reveal delay={0.2}>
              <p className="mt-7 text-lg leading-relaxed text-white/60">
                Every brand deserves a digital presence that matches the care it puts into
                its product. Our mission is to close that gap — with engineering rigour,
                editorial design sensibility, and an allergy to anything generic.
              </p>
            </Reveal>
          </div>

          <Stagger className="mt-20 grid gap-px overflow-hidden border border-white/[0.07] bg-white/[0.07] sm:grid-cols-2 lg:grid-cols-4">
            {VALUES.map((v, i) => (
              <StaggerItem key={v.title} className="bg-obsidian p-8 md:p-10">
                <span className="text-[0.625rem] tracking-[0.26em] text-gold/70">
                  0{i + 1}
                </span>
                <h3 className="u-display mt-6 text-xl text-white">{v.title}</h3>
                <p className="mt-4 text-sm leading-relaxed text-mist">{v.body}</p>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      {/* Team */}
      <section className="py-24 md:py-36">
        <div className="u-container">
          <Reveal>
            <p className="u-eyebrow">The team</p>
          </Reveal>
          <SplitHeading
            text="Four senior people. No layers in between."
            accentFrom={3}
            className="u-display mt-6 max-w-3xl text-[clamp(2rem,4.6vw,3.5rem)] text-white"
          />

          <div className="mt-20 grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
            {TEAM.map((member, i) => (
              <Reveal key={member.name} delay={i * 0.08}>
                <article className="group">
                  <div className="relative flex aspect-[4/5] items-center justify-center overflow-hidden rounded-sm border border-white/[0.07] bg-gradient-to-br from-ink via-obsidian to-ink">
                    <div
                      aria-hidden
                      className="absolute inset-0 opacity-0 transition-opacity duration-700 group-hover:opacity-100"
                      style={{
                        background:
                          "radial-gradient(circle at 50% 30%, rgba(212,175,55,0.14), transparent 65%)",
                      }}
                    />
                    <span className="u-display u-gold-text relative text-6xl">
                      {member.initials}
                    </span>
                    <span className="absolute bottom-0 left-0 h-px w-0 bg-gold transition-all duration-[900ms] ease-[cubic-bezier(.22,1,.36,1)] group-hover:w-full" />
                  </div>
                  <h3 className="u-display mt-6 text-xl text-white">{member.name}</h3>
                  <p className="mt-1.5 text-[0.6875rem] uppercase tracking-[0.18em] text-gold/80">
                    {member.role}
                  </p>
                  <p className="mt-4 text-sm leading-relaxed text-mist">{member.bio}</p>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="border-t border-white/[0.07] py-24 md:py-36">
        <div className="u-container">
          <div className="grid gap-14 lg:grid-cols-12">
            <div className="lg:col-span-4">
              <Reveal>
                <p className="u-eyebrow">How we work</p>
              </Reveal>
              <SplitHeading
                text="Six phases. Zero surprises."
                accentFrom={2}
                className="u-display mt-6 text-[clamp(2rem,4vw,3rem)] text-white"
              />
              <Reveal delay={0.2}>
                <p className="mt-6 leading-relaxed text-mist">
                  Our process is deliberately transparent. You always know what phase we
                  are in, what is next, and what we need from you.
                </p>
              </Reveal>
              <Reveal delay={0.3}>
                <div className="mt-10">
                  <ButtonLink href="/contact">Book a discovery call</ButtonLink>
                </div>
              </Reveal>
            </div>

            <div className="lg:col-span-7 lg:col-start-6">
              <Stagger className="space-y-px overflow-hidden border border-white/[0.07] bg-white/[0.07]">
                {PROCESS.map((p) => (
                  <StaggerItem key={p.step} className="bg-obsidian">
                    <div className="group flex gap-7 p-7 transition-colors duration-500 hover:bg-ink/60 md:p-9">
                      <span className="u-display text-lg text-gold/60 transition-colors duration-500 group-hover:text-gold">
                        {p.step}
                      </span>
                      <div>
                        <h3 className="u-display text-xl text-white">{p.title}</h3>
                        <p className="mt-2.5 text-sm leading-relaxed text-mist">{p.body}</p>
                      </div>
                    </div>
                  </StaggerItem>
                ))}
              </Stagger>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

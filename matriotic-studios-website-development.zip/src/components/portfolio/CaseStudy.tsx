"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import { motion, useScroll, useTransform, useSpring, useReducedMotion } from "motion/react";

function useDesktop() {
  const [desktop, setDesktop] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 768px)");
    const on = () => setDesktop(mq.matches);
    on();
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);
  return desktop;
}

/** Scroll-linked image drift — mounted only on desktop. */
function DriftImage({ children }: { children: React.ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const imgY = useSpring(useTransform(scrollYProgress, [0, 1], ["-8%", "8%"]), {
    stiffness: 80,
    damping: 28,
  });
  return (
    <motion.div ref={ref} className="absolute inset-0" style={{ y: imgY, scale: 1.14 }}>
      {children}
    </motion.div>
  );
}

type Props = {
  index: number;
  slug: string;
  client: string;
  title: string;
  category: string;
  year: string;
  image: string;
  summary: string;
  results: readonly { readonly value: string; readonly label: string }[];
  stack: readonly string[];
};

const EASE = [0.22, 1, 0.36, 1] as const;

export default function CaseStudy(props: Props) {
  const { index, slug, client, title, category, year, image, summary, results, stack } = props;
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const flip = index % 2 === 1;
  const desktop = useDesktop();
  // parallax is desktop-only: iOS Safari breaks background-attachment-style
  // scroll-linked transforms and they cost frames on Android
  const parallaxActive = !reduce && desktop;
  const ImgLayer: React.ElementType = parallaxActive ? DriftImage : "div";

  return (
    <article
      id={slug}
      ref={ref}
      className="scroll-mt-28 border-b border-white/[0.07] py-20 md:py-28"
    >
      <div className="u-container grid items-center gap-12 lg:grid-cols-12 lg:gap-14">
        {/* Image with curtain reveal */}
        <div className={`lg:col-span-7 ${flip ? "lg:order-2 lg:col-start-6" : ""}`}>
          <div className="group relative aspect-[16/11] overflow-hidden rounded-sm bg-ink">
            <ImgLayer className="absolute inset-0">
              <Image
                src={image}
                alt={`${client} case study`}
                fill
                loading={index === 0 ? "eager" : "lazy"}
                priority={index === 0}
                sizes="(max-width: 1024px) 100vw, 58vw"
                decoding="async"
                className="object-cover transition-transform duration-[1400ms] ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.05]"
              />
            </ImgLayer>
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-obsidian/60 via-transparent to-transparent" />
            {/* curtain */}
            <motion.span
              aria-hidden
              className="absolute inset-0 z-10 bg-obsidian"
              initial={{ scaleY: 1 }}
              whileInView={{ scaleY: 0 }}
              viewport={{ once: true, margin: "-15% 0px" }}
              transition={{ duration: 1.25, ease: EASE }}
              style={{ originY: 1 }}
            />
            <motion.span
              aria-hidden
              className="absolute inset-x-0 bottom-0 z-20 h-px bg-gold"
              initial={{ scaleX: 1, opacity: 1 }}
              whileInView={{ scaleX: 0, opacity: 0 }}
              viewport={{ once: true, margin: "-15% 0px" }}
              transition={{ duration: 1.1, delay: 0.5, ease: EASE }}
            />
          </div>
        </div>

        {/* Copy */}
        <div className={`lg:col-span-5 ${flip ? "lg:order-1 lg:col-start-1" : ""}`}>
          <motion.div
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-12% 0px" }}
            variants={{ hidden: {}, show: { transition: { staggerChildren: 0.08 } } }}
          >
            {[
              <div key="meta" className="flex items-center gap-4">
                <span className="text-[0.625rem] uppercase tracking-[0.24em] text-gold">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <span className="h-px w-10 bg-gold/40" />
                <span className="text-[0.625rem] uppercase tracking-[0.18em] text-mist">
                  {category} · {year}
                </span>
              </div>,
              <h2 key="client" className="u-display mt-6 text-[clamp(1.9rem,4vw,3rem)] text-white">
                {client}
              </h2>,
              <p key="title" className="u-display mt-3 text-xl italic text-gold/90">
                {title}
              </p>,
              <p key="summary" className="mt-6 leading-relaxed text-mist">
                {summary}
              </p>,
              <div key="results" className="mt-9 grid grid-cols-3 gap-px border border-white/[0.07] bg-white/[0.07]">
                {results.map((r) => (
                  <div key={r.label} className="bg-obsidian px-4 py-5">
                    <p className="u-display text-2xl text-white">{r.value}</p>
                    <p className="mt-1.5 text-[0.625rem] uppercase leading-snug tracking-[0.12em] text-mist">
                      {r.label}
                    </p>
                  </div>
                ))}
              </div>,
              <div key="stack" className="mt-7 flex flex-wrap gap-2">
                {stack.map((s) => (
                  <span
                    key={s}
                    className="rounded-full border border-white/10 px-3.5 py-1.5 text-[0.6875rem] tracking-[0.06em] text-white/60"
                  >
                    {s}
                  </span>
                ))}
              </div>,
            ].map((node, i) => (
              <motion.div
                key={i}
                variants={{
                  hidden: { opacity: 0, y: 22 },
                  show: {
                    opacity: 1,
                    y: 0,
                    transition: { duration: 0.85, ease: EASE },
                  },
                }}
              >
                {node}
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </article>
  );
}
